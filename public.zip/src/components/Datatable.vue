<template>
    <!-- <div>
        <b-table striped hover :items="tabledata"
        :per-page="perPage" ref="my-table" 
        :current-page="currentPage"
        ></b-table>
        <b-overlay :show="isBusy" no-wrap opacity="0.5"></b-overlay>

        <b-pagination
            v-model="currentPage"
            :total-rows="rows"
            :per-page="perPage"
            aria-controls="my-table"
            ></b-pagination>
    </div> -->
    <div>
      <b-table ref="my-table" 
      id="table-id" 
      :items="items" 
      sticky-header responsive bordered show-empty ></b-table>
      <b-overlay :show="isBusy" no-wrap opacity="0.5"></b-overlay>
    </div>
</template>

<script>

export default {
  name: 'Datatable',
  props: {
    tabledata: [],
    perPage: null
  },
  created() {
    this.fetchItems();
  },
  data() {
      return {
        currentPage: 1,
        //fields: ["firstName", "lastName", "gender", "age", "number"],
        items: [],
        currentPage: 0,
        totalItems: 0,
        isBusy: false

      }
    },
    computed: {
      // rows() {
      //   return this.totalItems = this.tabledata.length
      // }
    },
    mounted() {

      //this.totalItems=tabledata.length
    const tableScrollBody = this.$refs["my-table"].$el;
    /* Consider debouncing the event call */
    tableScrollBody.addEventListener("scroll", this.onScroll);
  },
  beforeDestroy() {
    /* Clean up just to be sure */
    const tableScrollBody = this.$refs["my-table"].$el;
    tableScrollBody.removeEventListener("scroll", this.onScroll);
  },
  methods: {
    async fetchItems() {
      //alert(this.tabledata);
      /* No need to call if all items retrieved */
      if (this.items.length === this.tabledata.length) return;

      /* Enable busy state */
      this.isBusy = true;

      /* Missing error handling if call fails */
      const startIndex = this.currentPage++ * this.perPage;
      const endIndex = startIndex + this.perPage;
      const newItems = await this.callDatabase(startIndex, endIndex);

      /* Add new items to existing ones */
      this.items = this.items.concat(newItems);

      /* Disable busy state */
      this.isBusy = false;
    },
    /* mock database method */
    callDatabase(startIndex, endIndex) {
      
      let tableArray = this.tabledata
      return tableArray.slice(startIndex, endIndex);
    
    },
    onScroll(event) {
      if (
        event.target.scrollTop + event.target.clientHeight >=
        event.target.scrollHeight
      ) {
        if (!this.isBusy) {
          this.fetchItems();
        }
      }
    }
  },
  watch: {
    /* Optionally hide scrollbar when loading */
    isBusy(newVal, oldVal) {
      if (newVal !== oldVal) {
        const tableScrollBody = this.$refs["my-table"].$el;
        if (newVal === true) {
          tableScrollBody.classList.add("overflow-hidden");
        } else {
          tableScrollBody.classList.remove("overflow-hidden");
        }
      }
    }
  }
}
</script>

<style>
table tr td { }
</style>